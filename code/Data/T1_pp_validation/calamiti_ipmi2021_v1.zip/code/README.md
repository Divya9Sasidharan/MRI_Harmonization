# CALAMITI --- Contrast anatomy learning and analysis for MR image translation and integration 

Download the package through git: https://github.com/lianruizuo/calamiti.git

Please cite the paper as: 
```
@inproceedings{zuo2021information,
  title={Information-Based Disentangled Representation Learning for Unsupervised MR Harmonization},
  author={Zuo, Lianrui and Dewey, Blake E and Carass, Aaron and Liu, Yihao and He, Yufan and Calabresi, Peter A and Prince, Jerry L},
  booktitle={International Conference on Information Processing in Medical Imaging},
  pages={346--359},
  year={2021},
  organization={Springer}
}
```
